package lab13;

public interface LambdaPowerImp {
public int power(int x,int y);
}
