package lab13;

import java.util.Scanner;

public class LambdaPower {
public static void main(String args[])
{
LambdaPowerImp ex=(x,y)->{return (int) Math.pow(x,y);};
int re=ex.power(3,3);
System.out.println("power of  "+re);
}
}
