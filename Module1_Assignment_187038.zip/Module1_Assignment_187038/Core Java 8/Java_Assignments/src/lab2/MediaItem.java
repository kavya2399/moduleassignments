package lab2;

public class MediaItem extends Item{
	public MediaItem(){
		System.out.println("Media Item");
		
	}
	private float runtime;
	public float getRuntime(){
return runtime;		
	}
public void setRuntime()
{
	this.runtime=runtime;
}
}
