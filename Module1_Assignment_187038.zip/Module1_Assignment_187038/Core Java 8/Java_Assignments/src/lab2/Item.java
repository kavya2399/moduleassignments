package lab2;

public abstract class Item {
private int id;
private String Title;
private int noc;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public int getNoc() {
	return noc;
}
public void setNoc(int noc) {
	this.noc = noc;
}
public static void main(String args[])
{
	System.out.println("**Book**");
	Book n=new Book();
	System.out.println("**Video**");
	Video v=new Video();
	System.out.println("**Journal paper**");
	JournalPaper jp=new JournalPaper();
	System.out.println("**CD**");
	Cd c=new Cd();
}

}
