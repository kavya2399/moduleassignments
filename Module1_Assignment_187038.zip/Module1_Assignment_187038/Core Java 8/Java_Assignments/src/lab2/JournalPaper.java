package lab2;

public class JournalPaper extends WrittenItem{
	private int year;
	public JournalPaper()
	{
		
	System.out.println("Journal Paper");
	setAuthor("Karthika");
	setId(103);
	setTitle("Journals");
	setNoc(11);
	setYear(2019);
	show();
	}
	public int getYear(){
		return year;
	}
	public void setYear(int year)
	{
		this.year=year;
	}
	private void show() {
		// TODO Auto-generated method stub
		System.out.println("Journal Name"+getTitle());
		System.out.println("Journal Author"+getAuthor());
		System.out.println("Journal ID"+getId());
		System.out.println("Journal Year"+getYear());
		System.out.println("Journal Noc"+getNoc());
	}	
}
