package lab5;

public class FibSeries {
public static void main(String args[])
{
	int n1=1,n2=1,n=15;
	for(int i=1;i<=n;++i)
	{
		System.out.println(n1);
		int sum=n1+n2;
		n1=n2;
		n2=sum;
		
	}
}
}
