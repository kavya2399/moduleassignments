package lab5;

public class TrafficLight {
	public static void main (String args[])
	{
		String light="red";
		if(light== "red")
			System.out.println("Stop");
		else if(light== "yellow")
			System.out.println("Ready");
		else if(light=="green")
			System.out.println("Go");
		
			
	}
}
