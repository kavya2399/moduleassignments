package lab5;
import lab5.NameException;
	public class FnameLname {
		public String checkname(String fname,String lname) throws Exception{
			
			try {
				if(!fname.isEmpty() || !lname.isEmpty()) {
				
				System.out.println(fname);
				System.out.println(lname);
				}
				
			}catch(Exception e) {
				throw new NameException("invalid name");
			}
			return fname;
		}
		
		public static void main(String[] args) throws Exception {
			String fname="Kavya";
			String lname=null;
			FnameLname user=new FnameLname();
			user.checkname(fname,lname);
		}

	}


