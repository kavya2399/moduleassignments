package lab5;


	@SuppressWarnings("serial")
	public class NameException extends Exception{
		public NameException(String msg) {
			System.out.println(msg);
		}
	}



