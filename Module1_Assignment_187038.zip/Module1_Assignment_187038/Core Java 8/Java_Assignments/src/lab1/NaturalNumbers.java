package lab1;

public class NaturalNumbers {
	public int calculateSum(int n)// method to calculate the sum
	{
		int sum3,sum5,sumtotal,total=0,sum=0;
		sum3=((n/3)*(2*3+(n/3-1)*3)/2);
		sum5=((n/5)*(2*5+(n/5-1)*5)/2);
		sumtotal=((n/15)*(2*15+(n/15-1)*15)/2);//sum of first  natural numbers
		sum=sum3 + sum5 -sumtotal;
	return sum;
	}
public static void main(String args[])
{
	NaturalNumbers n=new NaturalNumbers();
	System.out.println(n.calculateSum(15));
	  
}
}
