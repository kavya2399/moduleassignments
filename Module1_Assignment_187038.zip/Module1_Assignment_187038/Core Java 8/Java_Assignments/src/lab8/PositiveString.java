package lab8;

	import java.util.Arrays;
	import java.util.Scanner; 
public class PositiveString {
			    static boolean positiveString(String s)  
			    {  
			        int n = s.length();  
			        char c[] = new char [n];
			        for (int i = 0; i < n; i++) {  
			            c[i] = s.charAt(i);  
			        }  
			        Arrays.sort(c);  
			        for (int i = 0; i < n; i++)  
			            if (c[i] != s.charAt(i))   
			                return false;  
			                
			        return true;      
			    }  
			      
			    @SuppressWarnings("resource")
				public static void main(String args[]) 
			    { 
			    	Scanner sc = new Scanner(System.in);
			        
			         System.out.println("enter the string");
			         String s = sc.next();
			        if (positiveString(s))  
			           System.out.println("It is Positive string");  
			        else
			            System.out.println("It is not Positive string");  
			            
			    } 
			
		 }
