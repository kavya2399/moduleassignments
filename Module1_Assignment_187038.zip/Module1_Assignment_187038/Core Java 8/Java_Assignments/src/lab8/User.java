package lab8;

import java.io.File;

public class User {
	public static void fileReader(String file) {
		File fr=new File(file);
		
		if (fr.exists()) {
			System.out.println("file is exists");
		}else {
			System.out.println("file not exit");
		}
		if (fr.canExecute()) {
			System.out.println("file can execute");
		}
		if (fr.canWrite()) {
			System.out.println("file can write ");
		}
		if(fr.canRead()) {
			System.out.println("file can read");
		}
		System.out.println("file name "+file);
		
		if(fr.isDirectory())
		{
			System.out.println(file +" is a Directory");
		}
		
		if(fr.isFile())
		{
			System.out.println(file +" is a File");
		}
	}
		
		public static void main(String[] args) {
		{
			fileReader("C:\\Users\\ka16\\Desktop\\Kavi.java\\JavaAssignments\\src\\lab8");
		}
	}
}
