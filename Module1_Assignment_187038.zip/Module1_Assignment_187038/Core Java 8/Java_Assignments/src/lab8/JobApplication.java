package lab8;

import java.util.StringTokenizer;



public class JobApplication {
	public static  boolean registeringUserName(String s)
	
	{
			if(s.endsWith("_job")) {
				StringTokenizer st=new StringTokenizer(s, "_job");
				int a=st.nextToken().length();
				if(a>8) 
				
					return true;
				else 
					return false;
			}
			else
		return false;	
	}
	public static void main(String[] args) {
	JobApplication obj=new JobApplication();
	System.out.println(obj.registeringUserName("Kavyaananthan_job"));
	
	}
}
