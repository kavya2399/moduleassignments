
package service;

import bean.Employee;;

public interface EmployeeInterface {
	public Employee addEmp(Employee emp);
	

}
