package pl;

import java.util.Scanner;

import bean.Employee;
import service.EmployeeServiceImpl;

public class Starter {
public static void main(String[] args) {
	EmployeeServiceImpl service=new EmployeeServiceImpl();
       @SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
       System.out.println("Enter your id");
       int id=sc.nextInt();
       System.out.println("Enter your name");
       String name=sc.next();
       System.out.println("Enter your Designation");
       String designation=sc.next();
       System.out.println("Enter your salary");
       int salary=sc.nextInt();
       Employee emp=new Employee();
       emp.setId(id);
       emp.setName(name);
       emp.setDesignation(designation);
       emp.setSalary(salary);
       service.addEmp(emp);
       System.out.println(emp.getInsuranceScheme());
}
}
