import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab4part1Component } from './lab4part1.component';

describe('Lab4part1Component', () => {
  let component: Lab4part1Component;
  let fixture: ComponentFixture<Lab4part1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab4part1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab4part1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
