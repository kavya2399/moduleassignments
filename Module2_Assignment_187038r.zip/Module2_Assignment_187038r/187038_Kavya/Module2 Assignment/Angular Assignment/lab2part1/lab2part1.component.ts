import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee.model';

@Component({
  selector: 'app-lab2part1',
  templateUrl: './lab2part1.component.html',
  styleUrls: ['./lab2part1.component.css']
})
export class Lab2part1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  obj = new Employee();
  arr=[];
  flag=0;
  flag2;
  index;
  activeindex=-1;
  

  addEmployee() {
    if(!this.obj.id || !this.obj.name || !this.obj.sal || !this.obj.dept) {
      return
    }
        this.arr.push(this.obj);
        this.obj = new Employee();
        this.flag++;  
  }

  deleteEmployee(id: number) {
    this.arr.splice(id,1);
    this.obj = new Employee();
    this.flag++; 
}

updateEmployee(ind) {
    this.index = ind;
    this.flag2=true;
  }

  updata(form) {
    if(form.id!=null) 
      this.arr[this.index].id=form.id
    if(form.name!=null) 
      this.arr[this.index].name=form.name
      if(form.salary!=null) 
      this.arr[this.index].salary=form.salary
      if(form.dept!=null) 
      this.arr[this.index].dept=form.dept
      this.flag2=false;
  }
}

