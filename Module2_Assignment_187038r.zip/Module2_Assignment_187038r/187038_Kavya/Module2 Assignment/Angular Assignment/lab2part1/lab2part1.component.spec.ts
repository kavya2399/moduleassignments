import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab2part1Component } from './lab2part1.component';

describe('Lab2part1Component', () => {
  let component: Lab2part1Component;
  let fixture: ComponentFixture<Lab2part1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab2part1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab2part1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
