package lab2;

public class Cd extends MediaItem{
private String genre;
private String artist;
public String getGenre()
{
	return genre;
	
}
public void setGenre(String genre)
{
	this.genre=genre;
	
}
public String getArtist(){
	return artist;
	
}
public void setArtist(String artist){
	this.artist=artist;
}
public Cd(){
	System.out.println("CD");
	setArtist("XXX");
	setId(10);
	setTitle("Yyy");
	setGenre("ttt");
	setNoc(123);
setRuntime();
show();
}

void show()
{
	System.out.println("CD name:"+getTitle());
	System.out.println("CD id:"+getId());
	System.out.println("CD noc:"+getNoc());
	System.out.println("Runtime"+getTitle());
	System.out.println("Artist:"+getTitle());
	System.out.println("Genre:"+getTitle());
	
}
}
