package lab2;

public class Video extends MediaItem{
	public Video(){
	
	System.out.println("Video");
	 setId(1234);
	 setTitle("Java");
	setGenre("Education");
    setNoc(12);
    
	setDirector("willsky");
	setYear(2019);
	show();
	
	}
	private String director;
	private String genre;
	private int year;
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void show()
	{
		// TODO Auto-generated method stub
		System.out.println("Video name:"+getTitle());	
		System.out.println("Video name:"+getId());
				System.out.println("Year"+getYear());
				System.out.println("genre"+getGenre());
				System.out.println("Directory"+getDirector());
				System.out.println("video noc:"+getNoc());
		
	}

}
