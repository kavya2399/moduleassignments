package lab2;

public class Book extends WrittenItem {
public  Book()
{
	System.out.println("Book Details");
	setAuthor("Kavss");
	setId(102);
	setTitle("Java");
	setNoc(12);
	show();
}
	
	private void show() {
	// TODO Auto-generated method stub
		System.out.println("ID:"+getId());
System.out.println("Title:"+getTitle());
System.out.println("Author:"+getAuthor());
System.out.println("Number of copies:"+getNoc());

}
}
