package lab8;

import java.util.Arrays;

public class Token {
	public static boolean stringCheck(String str) {
		char[]arr=str.toCharArray();
		//char b[]=a;
		Arrays.sort(arr);
		for (int i = 0; i < arr.length; i++) {
		if(arr[i]!=str.charAt(i)) {
			return false;
		}
		}	
	return true;
	}
}
