package com.cg.eis.exception;


public class EmpSalary {
	public static void salary(double sal){
		if (sal<3000) {
			try {
				throw new EmployeeException("\n"+sal+" salary is below 3000Rs ");
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
		}else {
			System.out.println("Salary of an employee"+sal);
		}
	}
	public static void main(String[] args) {
		salary(4999);
	}
	}

